clear

load h.dat
load eli.m2
eli1=eli;
load eli.s2
eli2=eli;
load eli.n2
eli3=eli;
load eli.k2
eli4=eli;
load eli.o1
eli5=eli;
load eli.k1
eli6=eli;
load eli.p1
eli7=eli;
load eli.q1
eli8=eli;

load elr.m2
elr1=elr;
load elr.s2
elr2=elr;
load elr.n2
elr3=elr;
load elr.k2
elr4=elr;
load elr.o1
elr5=elr;
load elr.k1
elr6=elr;
load elr.p1
elr7=elr;
load elr.q1
elr8=elr;

load ui.M2
ui1=ui;
load ui.S2
ui2=ui;
load ui.N2
ui3=ui;
load ui.K2
ui4=ui;
load ui.O1
ui5=ui;
load ui.K1
ui6=ui;
load ui.P1
ui7=ui;
load ui.Q1
ui8=ui;

load ur.M2
ur1=ur;
load ur.S2
ur2=ur;
load ur.N2
ur3=ur;
load ur.K2
ur4=ur;
load ur.O1   
ur5=ur;
load ur.K1
ur6=ur;
load ur.P1
ur7=ur;
load ur.Q1
ur8=ur;

load vi.M2
vi1=vi;
load vi.S2
vi2=vi;
load vi.N2
vi3=vi;
load vi.K2
vi4=vi;
load vi.O1
vi5=vi;
load vi.K1
vi6=vi;
load vi.P1
vi7=vi;
load vi.Q1
vi8=vi;

load vr.M2
vr1=vr;
load vr.S2
vr2=vr;
load vr.N2
vr3=vr;
load vr.K2
vr4=vr;
load vr.O1
vr5=vr;
load vr.K1
vr6=vr;
load vr.P1
vr7=vr;
load vr.Q1
vr8=vr;

save allconsts.mat

